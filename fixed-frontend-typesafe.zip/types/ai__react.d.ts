declare module "ai/react" {
  export * from "@ai-sdk/react";
}
